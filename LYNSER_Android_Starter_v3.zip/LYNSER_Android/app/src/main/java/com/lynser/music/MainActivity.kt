package com.lynser.music

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.URL

private val Bg = Color(0xFF101010)
private val Panel = Color(0xFF1C1C1E)
private val Accent = Color(0xFFFFFFFF)
private val Muted = Color(0xFF9A9A9A)

data class Track(val title: String, val artist: String, val album: String, val url: String, val artwork: String = "", val local: Boolean = false)

class MainActivity : ComponentActivity() {
    private var player: MediaPlayer? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LynserApp(
            onPlay = { track -> play(track) },
            onPlayClip = { track, millis -> playClip(track, millis) },
            onLoadLocal = { loadLocalTracks() },
            hasAudioPermission = {
                val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
                checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
            }
        ) }
    }
    private fun play(track: Track) {
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, Uri.parse(track.url))
                setOnPreparedListener { it.start() }
                prepareAsync()
            }
        } catch (_: Exception) {}
    }
    private fun playClip(track: Track, millis: Int) {
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, Uri.parse(track.url))
                setOnPreparedListener { mp ->
                    mp.start()
                    Handler(Looper.getMainLooper()).postDelayed({
                        try { if (mp.isPlaying) mp.pause() } catch (_: Exception) {}
                    }, millis.toLong())
                }
                prepareAsync()
            }
        } catch (_: Exception) {}
    }
    private fun loadLocalTracks(): List<Track> {
        val result = mutableListOf<Track>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM)
        contentResolver.query(collection, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, "${MediaStore.Audio.Media.TITLE} ASC")?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                result += Track(c.getString(titleCol) ?: "Unknown", c.getString(artistCol) ?: "Unknown artist",
                    c.getString(albumCol) ?: "", Uri.withAppendedPath(collection, id.toString()).toString(), local = true)
            }
        }
        return result
    }
    override fun onDestroy() { player?.release(); super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LynserApp(onPlay: (Track) -> Unit, onPlayClip: (Track, Int) -> Unit, onLoadLocal: () -> List<Track>, hasAudioPermission: () -> Boolean) {
    var tab by remember { mutableStateOf("Home") }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Track>>(emptyList()) }
    var local by remember { mutableStateOf<List<Track>>(emptyList()) }
    var current by remember { mutableStateOf<Track?>(null) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Discover music you love.") }
    var gameTracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var gameTrack by remember { mutableStateOf<Track?>(null) }
    var guess by remember { mutableStateOf("") }
    var gameMessage by remember { mutableStateOf("Tap New Game to get a random song.") }
    var clipLevel by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var gameLoading by remember { mutableStateOf(false) }
    val clipSteps = listOf(100, 500, 1000, 2000, 5000, 10000)
    val scope = rememberCoroutineScope()
    val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) local = onLoadLocal()
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Accent, onPrimary = Color.Black, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Color(0xFF171717)) {
                listOf("Home", "Search", "Games", "Library").forEach { name ->
                    NavigationBarItem(selected = tab == name, onClick = { tab = name },
                        icon = { Icon(when(name) { "Home" -> Icons.Default.Home; "Search" -> Icons.Default.Search; "Games" -> Icons.Default.SportsEsports; else -> Icons.Default.LibraryMusic }, null) },
                        label = { Text(name) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.Black, indicatorColor = Color.White, selectedTextColor = Color.White, unselectedTextColor = Muted))
                }
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 20.dp)) {
                Spacer(Modifier.height(20.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("LYNSER", fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.GraphicEq, null, tint = Color.White)
                }
                Spacer(Modifier.height(24.dp))
                when(tab) {
                    "Home" -> {
                        Text("Good music.\nGood mood.", fontSize = 31.sp, fontWeight = FontWeight.Bold, lineHeight = 36.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("Your sound, your space.", color = Muted)
                        Spacer(Modifier.height(24.dp))
                        Text("START LISTENING", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Spacer(Modifier.height(12.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth().clickable { tab = "Search" }) {
                            Column(Modifier.padding(20.dp)) {
                                Text("Find your next favorite", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Text("Search previews from the iTunes catalog", color = Muted, modifier = Modifier.padding(top = 6.dp))
                                Text("EXPLORE  →", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp))
                            }
                        }
                        Spacer(Modifier.height(24.dp))
                        Text("YOUR LIBRARY", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text("${local.size} local tracks available", modifier = Modifier.padding(top = 8.dp))
                        Button(onClick = { tab = "Library" }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black), modifier = Modifier.padding(top = 12.dp)) { Text("Open library") }
                    }
                    "Games" -> {
                        Text("Mini Games", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Text("Guess the Song", color = Muted)
                        Spacer(Modifier.height(18.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(18.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text("GUESS THE SONG", fontSize = 12.sp, color = Muted, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                                        Text("Score: $score", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Icon(Icons.Default.MusicNote, null, modifier = Modifier.size(38.dp))
                                }
                                Spacer(Modifier.height(12.dp))
                                Text("Listen to a short random clip and type the song title.", color = Muted)
                                Spacer(Modifier.height(14.dp))
                                Button(onClick = {
                                    gameLoading = true
                                    gameMessage = "Picking a random song..."
                                    scope.launch {
                                        gameTracks = searchItunes("top hits pop music").shuffled()
                                        gameTrack = gameTracks.firstOrNull()
                                        guess = ""
                                        clipLevel = 0
                                        gameMessage = if (gameTrack == null) "No playable previews found. Try again." else "Song ready! Play the first clip."
                                        gameLoading = false
                                    }
                                }, enabled = !gameLoading, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) {
                                    Text(if (gameLoading) "Loading..." else "New Game")
                                }
                                Spacer(Modifier.height(12.dp))
                                Text("Clip length", fontWeight = FontWeight.SemiBold)
                                Text(if (gameTrack == null) "—" else "${clipSteps[clipLevel] / 1000.0} sec", color = Muted)
                                Button(onClick = {
                                    gameTrack?.let { onPlayClip(it, clipSteps[clipLevel]) }
                                }, enabled = gameTrack != null, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF333333), contentColor = Color.White)) {
                                    Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Play ${if (gameTrack == null) "Clip" else "${clipSteps[clipLevel] / 1000.0}s Clip"}")
                                }
                                OutlinedTextField(value = guess, onValueChange = { guess = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Your guess") }, placeholder = { Text("Type song title") })
                                Button(onClick = {
                                    val answer = gameTrack?.title?.trim()?.lowercase()
                                    val attempt = guess.trim().lowercase()
                                    if (answer != null && attempt.isNotBlank()) {
                                        if (attempt == answer || answer.contains(attempt) && attempt.length >= 4) {
                                            score += 1
                                            gameMessage = "Correct! It was: ${gameTrack?.title} — ${gameTrack?.artist}"
                                            gameTrack = null
                                        } else {
                                            gameMessage = "Not quite. Try another clip or reveal a longer one."
                                            if (clipLevel < clipSteps.lastIndex) clipLevel++
                                            else gameMessage = "No more clips. The answer was ${gameTrack?.title}. Start a new game!"
                                        }
                                    }
                                }, enabled = gameTrack != null, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) { Text("Submit Guess") }
                                Text(gameMessage, color = Muted, modifier = Modifier.padding(top = 10.dp))
                                Text("Clip stages: 0.1s → 0.5s → 1s → 2s → 5s → 10s", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                            }
                        }
                    }
                    "Search" -> {
                        Text("Search", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Text("Songs, artists and albums", color = Muted)
                        Spacer(Modifier.height(16.dp))
                        OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Search music...") }, singleLine = true,
                            trailingIcon = { IconButton(onClick = {
                                if (query.isNotBlank()) {
                                    loading = true
                                    kotlinx.coroutines.MainScope().launch {
                                        results = searchItunes(query)
                                        loading = false
                                        if (results.isEmpty()) message = "No preview results found."
                                    }
                                }
                            }) { Icon(Icons.Default.Search, null) } })
                        Spacer(Modifier.height(12.dp))
                        if (loading) CircularProgressIndicator()
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(results) { track -> TrackRow(track) { current = track; onPlay(track) } }
                        }
                    }
                    else -> {
                        Text("Your library", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Text("Music stored on this device", color = Muted)
                        Spacer(Modifier.height(16.dp))
                        Button(onClick = {
                            if (hasAudioPermission()) local = onLoadLocal() else launcher.launch(permission)
                        }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("Scan local music") }
                        Spacer(Modifier.height(12.dp))
                        if (local.isEmpty()) Text("Your local tracks will appear here.", color = Muted)
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(local) { track -> TrackRow(track) { current = track; onPlay(track) } }
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
                current?.let { track ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF282828)), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(42.dp).background(Color(0xFF3A3A3A), RoundedCornerShape(9.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null) }
                            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                                Text(track.title, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text(track.artist, color = Muted, fontSize = 12.sp, maxLines = 1)
                            }
                            Icon(Icons.Default.Equalizer, null)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TrackRow(track: Track, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable { onClick() }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(46.dp).background(Color(0xFF333333), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = Color.White) }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(track.title, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(track.artist, color = Muted, fontSize = 12.sp, maxLines = 1)
        }
        Icon(Icons.Default.PlayArrow, null)
    }
}

suspend fun searchItunes(term: String): List<Track> = withContext(Dispatchers.IO) {
    try {
        val encoded = java.net.URLEncoder.encode(term, "UTF-8")
        val json = JSONObject(URL("https://itunes.apple.com/search?term=$encoded&entity=song&limit=25").readText())
        val arr = json.getJSONArray("results")
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val preview = o.optString("previewUrl")
                if (preview.isNotBlank() && preview != "null") add(Track(
                    o.optString("trackName", "Unknown"), o.optString("artistName", "Unknown artist"),
                    o.optString("collectionName", ""), preview, o.optString("artworkUrl100", "")
                ))
            }
        }
    } catch (_: Exception) { emptyList() }
}
